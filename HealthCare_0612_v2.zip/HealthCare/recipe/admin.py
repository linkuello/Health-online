from django.contrib import admin

from recipe.models import food

admin.site.register(food)