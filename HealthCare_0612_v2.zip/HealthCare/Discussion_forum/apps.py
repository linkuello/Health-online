from django.apps import AppConfig


class DiscussionForumConfig(AppConfig):
    name = 'Discussion_forum'
