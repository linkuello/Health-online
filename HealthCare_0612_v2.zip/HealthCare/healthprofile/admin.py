from django.contrib import admin
from healthprofile.models import Profile, Contact

admin.site.register(Profile)
admin.site.register(Contact)
